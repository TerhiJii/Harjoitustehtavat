package tuote;

import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.validation.constraints.*;
import javax.faces.bean.*; 

@ManagedBean
@SessionScoped
public class Tuote implements java.io.Serializable{
	@Size(min=1, max=40)
    	private String nimi;
    	@Size(min=1, max=20)
    	private String koodi;
    	@Min(0)
    	@Max(5000)
    	private double hinta;
    // getters, setters, constructor, toString() ...


    public Tuote() {
       	nimi=null;
	koodi=null;
	hinta=0.0;
    }
    
    public Tuote(String nimi, String koodi, double hinta) {
        this.nimi = nimi;
        this.koodi = koodi;
	this.hinta = hinta;
    }

    @Override
    public String toString() {
        return "Tuote:[nimi=" + nimi + "koodi=" + koodi + "hinta=" + hinta +"]";
    }
    
    public String getNimi() {
        return nimi;
    }

    public void setNimi(String nimi) {
        this.nimi = nimi;
    }

    public String getKoodi() {
        return koodi;
    }

    public void setKoodi(String koodi) {
        this.koodi = koodi;
    }

public double getHinta() {
        return hinta;
    }

    public void setHinta(double hinta) {
        this.hinta = hinta;
    }


    
}
