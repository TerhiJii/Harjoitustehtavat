package oppilas;

import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedBean;  

@ManagedBean
@SessionScoped
public class Oppilas implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	int id;
	int demopisteet;
	int koepisteet;
	String nimi;
	
	
	public Oppilas() {
		this.id = 0;
		this.demopisteet = 0;
		this.koepisteet = 0;
		this.nimi = null;
	}


	public Oppilas(int id, int demopisteet, int koepisteet, String nimi) {
		super();
		this.id = id;
		this.demopisteet = demopisteet;
		this.koepisteet = koepisteet;
		this.nimi = nimi;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getDemopisteet() {
		return demopisteet;
	}


	public void setDemopisteet(int demopisteet) {
		this.demopisteet = demopisteet;
	}


	public int getKoepisteet() {
		return koepisteet;
	}


	public void setKoepisteet(int koepisteet) {
		this.koepisteet = koepisteet;
	}


	public String getNimi() {
		return nimi;
	}


	public void setNimi(String nimi) {
		this.nimi = nimi;
	}
	
	public int getYhteispisteet(){
		int pisteetYhteensa = this.demopisteet + this.koepisteet;
		return pisteetYhteensa;
	}
	
	


    
}
