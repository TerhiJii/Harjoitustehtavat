package oppilas;


import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.activation.DataSource;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedBean;  

@ManagedBean
@SessionScoped

public class Oppilaat {
	private DataSource ds;
	
	 //JDBC driver name and database URL
	 static final String JDBC_DRIVER = "org.h2.Driver";  
	 static final String DB_URL = "jdbc:h2:tcp://localhost:9092/mem:jpatest";

	public Oppilaat() {
		super();
		this.ds = null;
	}
	
	public Connection luoYhteys() throws SQLException, ClassNotFoundException{
		
		Connection conn = null;
		
		 Class.forName("org.h2.Driver");
		 conn = DriverManager.getConnection(DB_URL);

		return conn;
		
	}
	
	public List<Oppilas> getOppilaat(){
		List<Oppilas> oppilaslista = new ArrayList<Oppilas>();
		Statement stmt = null;
		
		 ResultSet rs = stmt.executeQuery("select * from oppilas");
		 
		 oppilaslista.add(rs.getInt("id"),rs.getInt("demopisteet"),rs.getInt("koepisteet"),rs.getString("nimi"));
		
		
	}
	
	
	
	
	
	
	
	
	

}
