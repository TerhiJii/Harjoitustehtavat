package osSystem;

import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedBean;  

@ManagedBean
@SessionScoped
public class OsSystem implements java.io.Serializable{

	private String name="ABC Operation System";
    	private String versio="0.11";
    
	// Kirjoita getterit, setterit ja konstruktori sekä toString()-metodi


    public OsSystem() {
        name = "ABC Operation System";
        versio =  "0.11";
    }
    
    public void Book(String name, String versio) {
        this.name = name;
        this.versio = versio;
    }

    @Override
    public String toString() {
        return "OsSystem: [nimi=" + name + ", versio " + versio +"]";
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersio() {
        return versio;
    }

    public void setVersio(String versio) {
        this.versio = versio;
    }


    
}
