package book;

import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedBean;  

@ManagedBean
@SessionScoped
public class Book implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private String isbn;
	


	private String tekijat;
	private String nimi;
	
	public Book() {
		
		this.isbn = null;
		this.tekijat = null;
		this.nimi = null;
	}
	
	
	public Book(String isbn, String tekijat, String nimi) {
		
		this.isbn = isbn;
		this.tekijat = tekijat;
		this.nimi = nimi;
	}


	public String getIsbn() {
		return isbn;
	}


	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}


	public String getTekijat() {
		return tekijat;
	}


	public void setTekijat(String tekijat) {
		this.tekijat = tekijat;
	}


	public String getNimi() {
		return nimi;
	}


	public void setNimi(String nimi) {
		this.nimi = nimi;
	}
	
	@Override
	public String toString() {
		return "Book [" + (isbn != null ? "isbn=" + isbn + ", " : "")
				+ (tekijat != null ? "tekijat=" + tekijat + ", " : "")
				+ (nimi != null ? "nimi=" + nimi : "") + "]";
	}
	

    
}
