import java.sql.*;

public class Database {
	
	// JDBC driver name and database URL
	  static final String JDBC_DRIVER = "org.h2.Driver";  
	  static final String DB_URL = "jdbc:h2:tcp://localhost:9092/mem:jpatest";
	  

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// Create database JDBC:llä
		//Use oppilas database which was used in JSP examples
		
		  Connection conn = null;
		   Statement stmt = null;
		 
		      //STEP 2: Register JDBC driver
		     Class.forName("org.h2.Driver");

		      //STEP 3: Open a connection
		      System.out.println("Connecting to a selected database...");
		      conn = DriverManager.getConnection(DB_URL);
		      System.out.println("Connected database successfully...");
		      
		      //STEP 4: Execute a query
		     /* System.out.println("Creating table in given database...");
		      stmt = conn.createStatement();
		      
		      String sql = "CREATE TABLE oppilas " +
		    		  		"(id integer NOT NULL,"+
		    		  		"nimi char(64) NOT NULL default '', "+
		    		  		"demopisteet integer(4) NOT NULL,"+
		    		  		"koepisteet integer(4) NOT NULL default '',"+
		    		  		"PRIMARY KEY (Id))";

		      stmt.executeUpdate(sql);
		      System.out.println("Created table in given database...");*/
		      
		   // Update database row using JDBC
		      stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, 
		      ResultSet.CONCUR_UPDATABLE);
		      ResultSet rs = stmt.executeQuery("select * from oppilas");
		      // Goto the first item in the result set
		      rs.first();
		      // Update: Add plus one point in the first student
		      
		      rs.updateInt("DEMOPISTEET", 11); // updates the
		      rs.updateRow();
		
		      
		      stmt = conn.createStatement();
		      rs = stmt.executeQuery("select * from oppilas");
		      while (rs.next()) {
		    	//Retrieve by column name
		        int id = rs.getInt("id");
		        String nimi = rs.getString("nimi");
		        int demopisteet = rs.getInt("demopisteet");
		        int koepisteet = rs.getInt("koepisteet");
		        
		      //Display values
		        System.out.print("ID: " + id);
		        System.out.print(", Nimi: " + nimi);
		        System.out.print(", Demopisteet: " + demopisteet);
		        System.out.println(", Koepisteet: " + koepisteet);
		      }
		      
		      conn.close();
		      
		      System.out.println("Goodbye!");

	}

}
