/**
 * 
 */
package fi.agileo.testi;

/**
 * @author oppi
 *
 */
public class TestiLuokka {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello ");
		System.out.println("world");

	}

}
