package Viikko1;

public class Koira {
	
	
String nimi;
Kissa jahdattava;
	
	

	public String toString() {
		return "Koira [nimi=" + nimi + "]";
	}



	public void jahtaa(Kissa kissa) {
		jahdattava = kissa;
		
	}
	

}
