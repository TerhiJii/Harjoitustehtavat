/**
 * 
 */
package Viikko1;

/**
 * @author oppi
 *
 */
public class Kertotaulu {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		
		for (int i = 1; i <= 10; i++) 
		{
		   System.out.println(i+ " x 10 =" +i*10 );
		}
		

	}

}
