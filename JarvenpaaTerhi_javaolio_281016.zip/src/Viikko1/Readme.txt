Harjoitus 1a --> Kertotaulu.java
Harjoitus 1b --> Kuusi.java

Harjoitus 2 --> Arvosanant.java
- hieman kesken

Harjoitus 3 --> Nopanheitto.java
- lisätehtävä b) puuttuu

Harjoitus 4 --> OmatFunkiot.java
- keskihajonnan laskeminen ei toimi

Harjoitus 5 --> Henkilo.java
				HenkiloTesti.java

Harjoitus 6 --> Taulukko.java
- puuttuu testiohjelma





