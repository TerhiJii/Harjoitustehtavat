package Viikko2;

public class Ajaja {
	Auto auto;
	String nimi;
	Ajotapa ajotapa;
	
	public enum Ajotapa{
		AGRESSIIVINEN(1), TAVALLINEN(0.7), RAUHALLINEN(0.4);
		
		private final double value;
		
		Ajotapa(double value){
			this.value = value;
			}
		}
	
	
	public Ajaja(Auto auto, String nimi, Ajotapa ajotapa) {
		
		this.auto = auto;
		this.nimi = nimi;
		this.ajotapa = ajotapa;
	}


	public Auto getAuto() {
		return auto;
	}


	public void setAuto(Auto auto) {
		this.auto = auto;
	}


	public String getNimi() {
		return nimi;
	}


	public void setNimi(String nimi) {
		this.nimi = nimi;
	}


	public Ajotapa getAjotapa() {
		return ajotapa;
	}


	public void setAjotapa(Ajotapa ajotapa) {
		this.ajotapa = ajotapa;
	}
	
	public double aja(double tuntia){
		double ajettuMatka;
		double nopeus = auto.laskeNopeus();
		
		//testausta varten
		
		//System.out.println("nopeus in Ajaja.java" +nopeus);
		//System.out.println("tuntia in Ajaja.java" +tuntia);
		//System.out.println("ajotapa in Ajaja.java" +ajotapa.value);
		
		
		ajettuMatka = nopeus * tuntia * ajotapa.value;
		
		return ajettuMatka;
		
	}


	@Override
	public String toString() {
		return "Ajaja [auto=" + auto + ", nimi=" + nimi + ", ajotapa="
				+ ajotapa + "]";
	}
	
	
	
	

}
