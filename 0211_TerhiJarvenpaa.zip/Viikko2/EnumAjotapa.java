package Viikko2;

public class EnumAjotapa {
	
	public enum LinkType{
	AGRESSIIVINEN(1), TAVALLINEN(0.7), RAUHALLINEN(0.4);
	
	private final double value;
	
	LinkType(double value){
		this.value = value;
		}
	}

}
