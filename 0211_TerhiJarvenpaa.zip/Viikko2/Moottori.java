package Viikko2;

public class Moottori {
	int teho;
	int sylinterienMaara;
	int sylintereitaRikki;
	
	public Moottori(int teho, int sylinterienMaara, int sylintereitaRikki) {
		
		this.teho = teho;
		this.sylinterienMaara = sylinterienMaara;
		this.sylintereitaRikki = sylintereitaRikki;
	}

	public int getTeho() {
		return teho;
	}

	public void setTeho(int teho) {
		
			this.teho = teho;
		
	}



	public int getSylinterienMaara() {
		return sylinterienMaara;
	}

	public void setSylinterienMaara(int sylinterienMaara) {
		this.sylinterienMaara = sylinterienMaara;
	}

	public int getSylintereitaRikki() {
		return sylintereitaRikki;
	}

	public void setSylintereitaRikki(int sylintereitaRikki) {
		this.sylintereitaRikki = sylintereitaRikki;	
		
	}
	
	
	public String toString() {
		return "Moottori [teho=" + teho + ", sylinterienMaara="
				+ sylinterienMaara + ", sylintereitaRikki=" + sylintereitaRikki
				+ "]";
	}
	

	public int meneRikki(){
		
		
		
		sylintereitaRikki =+ 1 + (int)(Math.random() * (sylinterienMaara - sylintereitaRikki));
		
		
		return sylintereitaRikki;
		
	}
	

}
