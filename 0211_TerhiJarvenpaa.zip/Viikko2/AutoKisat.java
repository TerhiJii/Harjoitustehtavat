package Viikko2;

import Viikko2.Ajaja.Ajotapa;
import Viikko2.EnumAjotapa.LinkType;

public class AutoKisat {

	public static void main(String[] args) {
		
		/*luot kolme autoa, 
	moottoria ja ajajaa, niin että yksi moo
	ttori ja ajaja on yhdessä autossa*/
		
	double testiAja;
	int testiRiko;
	double testiNopeus;
	
	Ajaja testiKuski1 = new Ajaja (null, "Teuvo", Ajotapa.AGRESSIIVINEN);
	Ajaja testiKuski2 = new Ajaja (null, "Tauno", Ajotapa.RAUHALLINEN);
	Ajaja testiKuski3 = new Ajaja (null, "Taneli", Ajotapa.TAVALLINEN);
	
	Moottori testiMoottori1 = new Moottori(100, 6, 0);
	Moottori testiMoottori2 = new Moottori(120, 6, 2);
	Moottori testiMoottori3 = new Moottori(140, 12, 0);
		
		
	Auto testiAuto1 = new Auto ("Volkkari", "Passat", 200, testiMoottori1, testiKuski1);
	Auto testiAuto2 = new Auto ("Volkkari", "Golf", 190, testiMoottori2, testiKuski2 );
	Auto testiAuto3 = new Auto ("Audi", "A6", 210, testiMoottori3, testiKuski3);
		
	
	System.out.println(testiAuto1.toString());
	System.out.println(testiAuto2.toString());
	System.out.println(testiAuto3.toString());
	
	testiNopeus = testiAuto1.laskeNopeus();
	
	System.out.println ("laskeNopeus tulos: " +testiNopeus);
	
	testiKuski1.setAuto(testiAuto1);
	
	testiAja = testiKuski1.aja(3.0);
	
	System.out.println("aja tulos" +testiAja);
	
	testiRiko = testiMoottori1.meneRikki();
	
	System.out.println("meneRikki tulos " +testiRiko);
	
	
	
	}

}
