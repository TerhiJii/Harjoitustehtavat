package book;

// JPA:n vaatimat kirjastojen importtaukset
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import java.util.List;

import javax.ejb.Stateless;

@Stateless
public class  BookEjb {
	
	
	@PersistenceContext(unitName = "jpa_book") // Name in persistence.xml
	
   
   private EntityManager em;

	public BookEjb() {

	}
	
	public void init() {
		Book b1 = new Book ();
        b1.setName("Java: A Beginner's Guide");
        b1.setAuthor("Herbert Schildt");
        b1.setEdition("6th Edition");
        b1.setPublisher("McGraw-Hill Education");
        b1.setPages(728);
        b1.setLanguage("English");
        b1.setCode("978-0071809252");
        
        
        Book b2 = new Book ();
        b2.setName("Elements of Programming Interviews in Java");
        b2.setAuthor("Adnan Aziz");
        b2.setEdition("2nd edition");
        b2.setPublisher("CreateSpace Independent Publishing Platform");
        b2.setPages(542);
        b2.setLanguage("English");
        b2.setCode("978-1517435806");
        
        Book b3 = new Book ();
        b3.setName("Functional Java: A Guide to Lambdas and Functional Programming in Java 8");
        b3.setAuthor("Nick Maiorano");
        b3.setEdition("1st edition");
        b3.setPublisher("ThoughtFlow Solutions inc.");
        b3.setPages(208);
        b3.setLanguage("English");
        b3.setCode("B00JZ7GD46");
        
        Book b4 = new Book ();
        b4.setName("Java EE 7: The Big Picture");
        b4.setAuthor("Dr. Danny Coward");
        b4.setEdition("1st edition");
        b4.setPublisher("McGraw-Hill Education");
        b4.setPages(512);
        b4.setLanguage("English");
        b4.setCode("978-0071837347");
        
        Book b5 = new Book ();
        b5.setName("Murach's Java Servlets and JSP");
        b5.setAuthor("Joel Murach");
        b5.setEdition("3rd edition");
        b5.setPublisher(" Mike Murach & Associates");
        b5.setPages(758);
        b5.setLanguage("English");
        b5.setCode("978-1890774783");

		//System.out.println("saved book: " + b1);
        
     // persist book in database
      
        em.persist(b1);
        em.persist(b2);
        em.persist(b3);
        em.persist(b4);
        em.persist(b5);
        
   
     	     
		
	}

	public void save(Book b) {
		try {
			em.persist(b);
			System.out.println("persist book:" + b);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Tallennus ei onnistunut!");
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public List<Book> getBooks() {
		List<Book> books = null; 
		// get all books from the database
		books = em.createNamedQuery("searchAllBooks").getResultList();
		System.out.println("*********** search all ********** => " + books);
		return books;
	}

	
	
}
