package jpaesim;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.Collection;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Kauppa
 *
 */
@javax.persistence.Entity
@Table(name = "KAUPPA2")
public class Kauppa implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String nimi;
	private String osoite;
	


	@ManyToMany( targetEntity=Tuote.class )
	private Collection<Tuote> tuotteet;


	public Kauppa() {
		super();
	}


	public String getNimi() {
		return nimi;
	}


	public void setNimi(String nimi) {
		this.nimi = nimi;
	}


	public String getOsoite() {
		return osoite;
	}


	public void setOsoite(String osoite) {
		this.osoite = osoite;
	}


	public Collection<Tuote> getTuotteet() {
		return tuotteet;
	}


	public void setTuotteet(Collection<Tuote> tuotteet) {
		this.tuotteet = tuotteet;
	}


	@Override
	public String toString() {
		return "Kauppa [" + (id != null ? "id=" + id + ", " : "")
				+ (nimi != null ? "nimi=" + nimi + ", " : "")
				+ (osoite != null ? "osoite=" + osoite + ", " : "")
				+ (tuotteet != null ? "tuotteet=" + tuotteet : "") + "]";
	}

	


}
