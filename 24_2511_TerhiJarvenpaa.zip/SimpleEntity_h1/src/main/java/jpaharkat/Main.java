package jpaharkat;

import javax.persistence.*;


import java.util.*;



class Main {
	public static void main(String[] args) throws Exception {
		 // Startataan H2 TCP-serverimoodissa
         org.h2.tools.Server server = org.h2.tools.Server.createTcpServer().start();


		EntityManagerFactory tehdas = Persistence
				.createEntityManagerFactory("jpa_SimpleEntity_harjoitus");
		EntityManager manageri = tehdas.createEntityManager();

		EntityTransaction transaktio = manageri.getTransaction();

		transaktio.begin();

		SimpleEntity p1 = new SimpleEntity();
		p1.setName("Kello");
		p1.setDesc("kellokellokello");
		
		SimpleEntity p2 = new SimpleEntity();
		p2.setName("Kenkä");
		p2.setDesc("kenkäkenkäkenkä");
		
		SimpleEntity p3 = new SimpleEntity();
		p3.setName("Kala");
		p3.setDesc("kalakalakal");
		
		SimpleEntity p4 = new SimpleEntity();
		p4.setName("Tuoli");
		p4.setDesc("kukkakaukkakakuk");
		

		manageri.persist(p1);
		manageri.persist(p2);
		manageri.persist(p3);
		manageri.persist(p4);

		transaktio.commit();
		
	
		@SuppressWarnings("unchecked")
		List<SimpleEntity> entiteetit = manageri.createNamedQuery("selectAll")
				.getResultList();
		for (SimpleEntity e : entiteetit) {
			System.out.println("Rivi: " + e);
		}
		
		//Filter all SimpleEntity entities that starts with letter K
		
		TypedQuery<SimpleEntity> kysely = manageri.createQuery("SELECT se from SimpleEntity se WHERE se.name like \"K%\"", SimpleEntity.class);
		List<SimpleEntity> tulokset = kysely.getResultList();
		
		 System.out.println();
		System.out.println("all SimpleEntity entities that starts with letter K:");
        System.out.println("----------------------------------------------------");
        
        for (SimpleEntity se : tulokset) {
            System.out.println(se.getName());
         }
        System.out.println();
        
        //Filter all SimpleEntity entities that includes letter A.
        
        TypedQuery<SimpleEntity> kyselyA = manageri.createQuery("SELECT se from SimpleEntity se WHERE se.name like \"%a%\"", SimpleEntity.class);
		List<SimpleEntity> tuloksetA = kyselyA.getResultList();
		
		 System.out.println();
		System.out.println("all SimpleEntity entities includes letter a:");
        System.out.println("---------------------------------------------");
        
        for (SimpleEntity se : tuloksetA) {
            System.out.println(se.getName());
         }
        System.out.println();
        
        //Haku – Query parameters
        
        TypedQuery<SimpleEntity> kyselyQP = manageri.createQuery(
                "SELECT se FROM SimpleEntity se WHERE se.name like :name", SimpleEntity.class);
        List<SimpleEntity> listaQP = kyselyQP.setParameter("name", "%l%").getResultList();
		
		System.out.println("entities which has letter l in name:");
        System.out.println("-------------------------------------");
		for (SimpleEntity se : listaQP) {
            System.out.println(se.getName());
            
        }
		
		System.out.println();
		
		//Remove all entities that includes letter ä or l.
		
		TypedQuery<SimpleEntity> poisto = manageri.createQuery("SELECT se from SimpleEntity se WHERE se.name like \"%ä%\" OR se.name like \"%l%\"", SimpleEntity.class);
		List<SimpleEntity> poistolista = poisto.getResultList();
        
		System.out.println("entities which has letter l or ä will be removed:");
        System.out.println("-------------------------------------------------");
		
		for (SimpleEntity se : poistolista) {
            System.out.println(se.getName());
            
        }
		
		transaktio.begin();
	       
	        for (SimpleEntity se : poistolista) {
	            manageri.remove(se);
	            }
	        
	    transaktio.commit();
         
		
		manageri.close();
		tehdas.close();

        // Lopetetaan h2-palvelin
        server.stop();

	}
}