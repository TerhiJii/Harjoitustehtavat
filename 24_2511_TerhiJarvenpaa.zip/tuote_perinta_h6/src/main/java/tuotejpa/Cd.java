package tuotejpa;

import java.io.Serializable;

import javax.persistence.*;

import tuotejpa.Tuote;

/**
 * Entity implementation class for Entity: Cd
 *
 */
@Entity

@NamedQueries({
	@NamedQuery(name = "etsiKaikkiLevyt", query = "SELECT cd from Cd cd"),
	@NamedQuery(name = "etsiKaalliitLevyt", query = "SELECT cd from Cd cd WHERE cd.hinta > :rajahinta")
})
public class Cd extends Tuote {
	private String artisti;
        private int pituus;
        private int biiseja;

  // TODO: getters, setters, constructor + toString()
        
    

	public Cd() {
		super();
	}

	

	public Cd(String nimi, double hinta, String artisti, int pituus, int biiseja) {
		super(nimi, hinta);
		this.artisti = artisti;
		this.pituus = pituus;
		this.biiseja = biiseja;
	}



	public String getArtisti() {
		return artisti;
	}

	public void setArtisti(String artisti) {
		this.artisti = artisti;
	}

	public int getPituus() {
		return pituus;
	}

	public void setPituus(int pituus) {
		this.pituus = pituus;
	}

	public int getBiiseja() {
		return biiseja;
	}

	public void setBiiseja(int biiseja) {
		this.biiseja = biiseja;
	}

	@Override
	public String toString() {
		return "Cd [" + (artisti != null ? "artisti=" + artisti + ", " : "")
				+ "pituus=" + pituus + ", biiseja=" + biiseja + "]";
	}
	
	


}
