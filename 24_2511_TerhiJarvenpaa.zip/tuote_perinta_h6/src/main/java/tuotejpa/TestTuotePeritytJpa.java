package tuotejpa;

import java.util.List;

import javax.persistence.*;

public class TestTuotePeritytJpa {

	public static void main(String[] args) throws Exception {
		// Startataan H2 TCP-serverimoodissa
        org.h2.tools.Server server = org.h2.tools.Server.createTcpServer().start();

		EntityManagerFactory tehdas = Persistence.createEntityManagerFactory("jpa_tuoteperityt");
		EntityManager manageri = tehdas.createEntityManager();

		EntityTransaction transaktio = manageri.getTransaction();

		transaktio.begin();

		Kirja k1 = new Kirja();
		k1.setIsbn("A123");
		k1.setNimi("Core Java");
		k1.setHinta(26.99); 
		k1.setTekijat("Cay Horstmann"); 

		Kirja k2 = new Kirja(); 
		k2.setIsbn("A223"); 
		k2.setNimi("JavaScript Ninja"); 
		k2.setTekijat("John Resig"); 
		k2.setHinta(33.50); 

		Kirja k3 = new Kirja(); 
		k3.setIsbn("A313"); 
		k3.setNimi("Thinking Of Java"); 
		k3.setTekijat("Bruce Eckel"); 
		k3.setHinta(9.95); 

		Cd cd1 = new Cd("Powerslave", 19.95, "Iron Maiden", 3048, 8);  
		Cd cd2 = new Cd("Full Moon Fever", 14.95, "Tom Petty", 2398, 12); 
		Cd cd3 = new Cd("Luotan Sydämen Ääneen",4.95,"Paula Koivuniemi", 2850, 12); 
		Cd cd4 = new Cd("Abbey Road",29.95, "The Beatles", 2545, 17); 

		// TODO: Save Cd and Kirja entities, check database




		manageri.persist(k1);
		manageri.persist(k2);
		manageri.persist(k3);
		manageri.persist(cd1);
		manageri.persist(cd2);
		manageri.persist(cd3);
		manageri.persist(cd4);

		transaktio.commit();
		
		//Search all Kirja entities
		
		@SuppressWarnings("unchecked")
        List<Kirja> kirjat = manageri.createNamedQuery("etsiKaikkiKirjat").getResultList();
        
		System.out.println("all books:");
        System.out.println("-----------");
		for (Kirja k : kirjat) {
            System.out.println(k.toString());
        }
        
        // Search all Cd entities
        
        @SuppressWarnings("unchecked")
        List<Cd> levyt = manageri.createNamedQuery("etsiKaikkiLevyt").getResultList();
        
        System.out.println("all cds:");
        System.out.println("---------");
        for (Cd cd : levyt) {
            System.out.println(cd.toString());
        }
        
        //Search the most expensive Cd entities
        List<Cd> haetut2 = manageri.createNamedQuery("etsiKaalliitLevyt").setParameter("rajahinta", 15).getResultList();
        System.out.println("most expensive Cd entities:");
        System.out.println("---------------------------");
		for (Cd cd : haetut2) {
            System.out.println(cd.getNimi());
            System.out.println(cd.getHinta());
            
        }
		
		//Search Cheapest Tuote entities (so also Kirja and Cd)
		
		List<Tuote> haetut3 = manageri.createNamedQuery("etsiHalvatTuotteet").setParameter("rajahinta", 15).getResultList();
		 System.out.println("most expensive tuote entities:");
	     System.out.println("------------------------------");
		for (Tuote t : haetut3) {
	            System.out.println(t.getNimi());
	            System.out.println(t.getHinta());
	     }

		manageri.close();
		tehdas.close();
        // Lopetetaan h2-palvelin
        server.stop();

	}
}
