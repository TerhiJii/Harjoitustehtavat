package tuotejpa;

//import java.io.Serializable;
import javax.persistence.*;

@javax.persistence.Entity
@NamedQuery(name = "etsiKaikkiKirjat", query = "SELECT k from Kirja k")
public class Kirja extends Tuote {
	private String isbn;
        private String tekijat;

  // TODO: getters, setters, constructor + toString()

	public Kirja() {
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTekijat() {
		return tekijat;
	}

	public void setTekijat(String tekijat) {
		this.tekijat = tekijat;
	}

	@Override
	public String toString() {
		return "Kirja [" + (isbn != null ? "isbn=" + isbn + ", " : "")
				+ (tekijat != null ? "tekijat=" + tekijat : "") + "]";
	}

	
	
	

}
