package jpaesim;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Tuote
 *
 */
@javax.persistence.Entity
@Table(name = "TUOTE")
@NamedQuery(name = "selectAll", query = "SELECT t from Tuote t")
public class Tuote implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	private static final long serialVersionUID = 1L;
	
	 private String nimi;
	 private String koodi;
	 private double hinta;

	// Määrittelee tuote - kauppa suhteen 1 - n 
		@OneToMany ( targetEntity=Kauppa.class )
		public List<Kauppa> kaupat;
	
	 
	 public Tuote() {
			super();
		}

	public Integer getId() {
		return id;
	}

	

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNimi() {
		return nimi;
	}

	public void setNimi(String nimi) {
		this.nimi = nimi;
	}

	public String getKoodi() {
		return koodi;
	}

	public void setKoodi(String koodi) {
		this.koodi = koodi;
	}

	public double getHinta() {
		return hinta;
	}

	public void setHinta(double hinta) {
		this.hinta = hinta;
	}
	
	

	

	public void setKaupat(List<Kauppa> kaupat) {
		this.kaupat = kaupat;
	}
	
	

	public List<Kauppa> getKaupat() {
		return kaupat;
	}

	@Override
	public String toString() {
		return "Tuote [" + (id != null ? "id=" + id + ", " : "")
				+ (nimi != null ? "nimi=" + nimi + ", " : "")
				+ (koodi != null ? "koodi=" + koodi + ", " : "") + "hinta="
				+ hinta + ", " + (kaupat != null ? "kaupat=" + kaupat : "")
				+ "]";
	}

	
	
	

}
